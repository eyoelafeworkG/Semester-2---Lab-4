// This is a template program for you to test the pre-lab exercises in lab 4

// Date: Place the date here
// Name: Place your name here
// ID: Place your ID here

#include <iostream>

using namespace std;

/// Insert in the declaration of your distance2 function on the next line
	
/// End of the function declaration for distance2 function
int main()
{
	/// Insert in the lines of code to test your function by calling it with various arguments starting from the next line
	/// e.g., Use (3.0, 0.0) and (0.0, 4.0) as one pair of arguments
	
	
	/// End of the function call lines	
	return 0;
}

/// Insert in the definition of the distance2 function starting from the next line
	
/// End of the definition of distance2 function