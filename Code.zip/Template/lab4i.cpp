// This is a a template program for you to submit lab exercises in lab 4
// Lab Title: Sum of even numbers in range 
// Date: Place the date here
// Name: Place your name here
// ID: Place your ID here

#include <iostream>

using namespace std;


//Declaration of the sumNums function
int sumNums(int n,int m);
// End of function declaration

int main()
{
	// A variable to hold the input value
	int n = 0,m = 0;

	cout<<"Input n :";
	cin>>n;
	cout<<"Input m :";
	cin>>m;
	
	cout<<" The sum of even numbers between "<< n <<" and "<< m <<" is "<< sumNums(n,m)<<endl;
	
	return 0;
}
int sumNums(int n, int m)
{
	/// Insert the body of your sumNums function here
	
	/// End of the body of your function
}