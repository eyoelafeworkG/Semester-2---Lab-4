// This is a a template program for you to submit lab exercises in lab 4
// Lab Title: Maximum of three
// Date: Place the date here
// Name: Place your name here
// ID: Place your ID here

#include <iostream>

using namespace std;


/// Insert in the declaration of your max function on the next line
	
/// End of the function declaration for max function

int main()
{
	// A variable to hold the input value
	int number1,number2,number3;

	cout<<"Input the first number:";
	cin>>number1;
	cout<<"Input the second number:";
	cin>>number2;
	cout<<"Input the third number:";
	cin>>number3;

	cout<<"The maximum of "<<number1<<","<<number2<<","<<number3<<" is "<< max(number1,number2,number3);
	if (isPrime (j) == 0) // call the function isPrime(j) to check
		{
			// action to be performed when j is prime 
		}
		else{
			// action to be performed when j is NOT a prime number
		}
	}
	// Any additional action required when the checking completes
	return 0;
}

/// Insert in the definition of the isPrime function starting from the next line
	
/// End of the definition of isPrime function