// This is a a template program for you to test the pre-lab exercises in lab 4
// Date: Place the date here
// Name: Place your name here
// ID: Place your ID here

#include <iostream>

using namespace std;

double quadratic(double);

int main()
{
	cout<<"quadratic(3.0) "<< quadratic(3.0)<<endl;
	cout<<"quadratic(4.0) "<< quadratic(4.0)<<endl;
	cout<<"quadratic(5.0) "<< quadratic(5.0)<<endl;
	
	return 0;
}

/// Insert in the definition of the quadratic function starting from the next line
	
/// End of the definition of quadratic function