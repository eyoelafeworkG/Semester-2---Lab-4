// This is a a template program for you to submit lab exercises in lab 4
// Lab Title: Check Case
// Date: Place the date here
// Name: Place your name here
// ID: Place your ID here

#include <iostream>

using namespace std;


//Declaration of the isCapital  function
int isCapital (char c);
// End of function declaration

int main()
{
	// A variable to hold the input value
	char inputChar;

	/// Put your code to accept a character from the user here
	
	/// End of your code to accept a character
	
	/// Check if the character is in capital case or not 
	/// Display C if it is so
	/// Display c otherwise 
	
	return 0;
}
int isCapital (char c)
{
	/// Insert the body of your isCapital  function here
	
	/// End of the body of your function
}